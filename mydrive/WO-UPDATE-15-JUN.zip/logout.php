<?php
require_once("function_logout.php");
?>
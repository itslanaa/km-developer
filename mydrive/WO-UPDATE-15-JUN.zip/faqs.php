<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700;800&display=swap"
    rel="stylesheet">
  <title>Pertanyaan yang sering dipertanyakan - FAQ</title>
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/fontawesome.css">
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="assets/css/owl.css">
  <link rel="stylesheet" href="assets/css/animate.css">
  <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />
</head>

<body>
  <div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div>

  <div class="pre-header" id="top">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-sm-9">
          <div class="left-info">
            <ul>
              <li><a href="#"><i class="fa fa-phone"></i>+62 221032211</a></li>
              <li><a href="#"><i class="fa fa-envelope"></i>info@unpwedding.com</a></li>
              <li><a href="#"><i class="fa fa-map-marker"></i>Jl. Pakuan, RT.02/RW.06, Tegallega, Kota Bogor, Jawa Barat
                  16129</a></li>
            </ul>
          </div>
        </div>
        <div class="col-lg-4 col-sm-3">
          <div class="social-icons">
            <ul>
              <li><a href="#"><i class="fab fa-facebook"></i></a></li>
              <li><a href="#"><i class="fab fa-twitter"></i></a></li>
              <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
              <li><a href="#"><i class="fab fa-google-plus"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  <header class="header-area header-sticky">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <nav class="main-nav">
            <a href="index.php" class="logo">
              <img src="assets/images/logo.png" alt="">
            </a>

            <ul class="nav">
              <li class="scroll-to-section"><a href="index.php#top" class="active">Home</a></li>
              <li class="scroll-to-section"><a href="index.php#package">Paket</a></li>
              <li class="scroll-to-section"><a href="index.php#galeri">Galeri Photo</a></li>
              <li class="scroll-to-section"><a href="faqs.php">FAQ</a></li>
            </ul>
            <a class='menu-trigger'>
              <span>Menu</span>
            </a>
          </nav>
        </div>
      </div>
    </div>
  </header>

  <div class="page-heading mt-0">
    <div class="container">
      <div class="row">
        <div class="col-lg-7 align-self-center">
          <div class="caption  header-text">
            <h6>Wedding Organizer</h6>
            <div class="line-dec"></div>
            <h4>Pertanyaan yang Sering <em>Ditanyakan</em> (FAQ)</h4>
          </div>
        </div>
        <div class="col-lg-5">
          <img src="assets/images/faqs-image.png" alt="">
        </div>
      </div>
    </div>
  </div>

  <div class="most-asked section">
    <div class="container">
      <div class="row">
        <div class="accordion" id="accordionExample">
          <div class="accordion-item">
            <h2 class="accordion-header" id="heading1">
              <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapse1"
                aria-expanded="true" aria-controls="collapse1">
                Paket sudah termasuk(mencakup) apa saja?
              </button>
            </h2>
            <div id="collapse1" class="accordion-collapse collapse show" aria-labelledby="heading1"
              data-bs-parent="#accordionExample">
              <div class="accordion-body">
                <strong>Semua sudah ada didalam paket</strong> (All in package).
              </div>
            </div>
          </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="heading2">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                data-bs-target="#collapse2" aria-expanded="false" aria-controls="collapse2">
                Apakah ada 2 atau lebih event wedding dalam satu hari?
              </button>
            </h2>
            <div id="collapse2" class="accordion-collapse collapse" aria-labelledby="heading2"
              data-bs-parent="#accordionExample">
              <div class="accordion-body">
                <strong>Ya.</strong> Kami bisa menerima 3 event wedding sekaligus dalam satu hari (ditanggal yang sama), namun setiap event
                tentu saja berbeda venue dan gedung karena berbeda dari masing-masing paket. 
              </div>
            </div>
          </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="heading3">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                data-bs-target="#collapse3" aria-expanded="false" aria-controls="collapse3">
                Bisa menampung berapa tamu undangan untuk area gedung?
              </button>
            </h2>
            <div id="collapse3" class="accordion-collapse collapse" aria-labelledby="heading3"
              data-bs-parent="#accordionExample">
              <div class="accordion-body">
                <strong>Sesuai dengan paket wedding yang dipilih.</strong><br>
                Untuk <strong>Bronze Package</strong> kapasitas ± 200 tamu<br>
                Untuk <strong>Silver Package</strong> kapasitas ± 500 tamu<br>
                Untuk <strong>Gold Package</strong> kapasitas ± 1000 tamu<br>
                selengkapnya silahkan cek <a href="index.php#package">Halaman Paket</a>
              </div>
            </div>
          </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="heading4">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                data-bs-target="#collapse4" aria-expanded="false" aria-controls="collapse4">
                Bagaimana ketentuan jika acara pernikahan lewat dari kesepakatan waktu?
              </button>
            </h2>
            <div id="collapse4" class="accordion-collapse collapse" aria-labelledby="heading4"
              data-bs-parent="#accordionExample">
              <div class="accordion-body">
                Dikenakan biaya overtime untuk after party.
              </div>
            </div>
          </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="heading5">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                data-bs-target="#collapse5" aria-expanded="false" aria-controls="collapse5">
                Jika ingin memesan paket weddingnya saja tanpa gedung apakah bisa?
              </button>
            </h2>
            <div id="collapse5" class="accordion-collapse collapse" aria-labelledby="heading5"
              data-bs-parent="#accordionExample">
              <div class="accordion-body">
                <strong>Sangat bisa.</strong> Silahkan hubungi kami melalui live chat / sosial media / 
                Email : unpwedding@gmail.com. untuk kustomisasi pesanan diluar paket.
              </div>
            </div>
          </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="heading6">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                data-bs-target="#collapse6" aria-expanded="false" aria-controls="collapse6">
                Apakah pihak gedung menyediakan pengamanan atau harus kita sediakan sendiri?
              </button>
            </h2>
            <div id="collapse6" class="accordion-collapse collapse" aria-labelledby="heading6"
              data-bs-parent="#accordionExample">
              <div class="accordion-body">
                Pengamanan selama berada di dalam kawasan gedung menjadi tanggung jawab pengelola gedung
              </div>
            </div>
          </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="heading7">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                data-bs-target="#collapse7" aria-expanded="false" aria-controls="collapse7">
                Kapan bisa melakukan gladiresik pernikahan?
              </button>
            </h2>
            <div id="collapse7" class="accordion-collapse collapse" aria-labelledby="heading7"
              data-bs-parent="#accordionExample">
              <div class="accordion-body">
                Tergantung dari rundown acara pengantin, biasanya sekitar 2 jam sebelum acara
              </div>
            </div>
          </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="heading8">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                data-bs-target="#collapse8" aria-expanded="false" aria-controls="collapse8">
                Bagaimana cara melakukan pembayaran?
              </button>
            </h2>
            <div id="collapse8" class="accordion-collapse collapse" aria-labelledby="heading8"
              data-bs-parent="#accordionExample">
              <div class="accordion-body">
                <strong>Sangat Mudah.</strong> Anda bisa melakukan pembayaran melalui transfer semua bank<br>
                atau e-wallet, asalkan nama pengirim harus sama dengan nama akun yaa^^
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <footer>
    <div class="container">
      <div class="col-lg-12">
        <p>Copyright © 2024 <a href="#">UNPwedding</a>. All rights reserved.
        </p>
      </div>
    </div>
  </footer>
  
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

  <script src="assets/js/isotope.min.js"></script>
  <script src="assets/js/owl-carousel.js"></script>
  <script src="assets/js/tabs.js"></script>
  <script src="assets/js/popup.js"></script>
  <script src="assets/js/custom.js"></script>

</body>

</html>